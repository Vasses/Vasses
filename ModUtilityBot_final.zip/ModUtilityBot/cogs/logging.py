import discord
from discord.ext import commands
import os
import datetime

class Logging(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    def get_log_channel(self, guild):
        """Get the logging channel for a guild"""
        channel_id = int(os.getenv('LOG_CHANNEL_ID', 0))
        if channel_id == 0:
            return None
        return guild.get_channel(channel_id)
    
    def create_log_embed(self, title, description, color=0x5865F2):
        """Create a standardized log embed"""
        embed = discord.Embed(
            title=title,
            description=description,
            color=color,
            timestamp=datetime.datetime.utcnow()
        )
        return embed
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Log when a member joins"""
        log_channel = self.get_log_channel(member.guild)
        if not log_channel:
            return
        
        embed = self.create_log_embed(
            "📥 Member Joined",
            f"{member.mention} ({member.name}#{member.discriminator})",
            0x00FF00
        )
        embed.add_field(name="Account Created", value=member.created_at.strftime("%B %d, %Y"), inline=True)
        embed.add_field(name="User ID", value=member.id, inline=True)
        embed.set_thumbnail(url=member.display_avatar.url)
        
        await log_channel.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """Log when a member leaves"""
        log_channel = self.get_log_channel(member.guild)
        if not log_channel:
            return
        
        embed = self.create_log_embed(
            "📤 Member Left",
            f"{member.mention} ({member.name}#{member.discriminator})",
            0xFF0000
        )
        embed.add_field(name="Joined Server", value=member.joined_at.strftime("%B %d, %Y") if member.joined_at else "Unknown", inline=True)
        embed.add_field(name="Roles", value=len(member.roles) - 1, inline=True)
        embed.set_thumbnail(url=member.display_avatar.url)
        
        await log_channel.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        """Log member updates (nickname, roles)"""
        log_channel = self.get_log_channel(after.guild)
        if not log_channel:
            return
        
        if before.nick != after.nick:
            embed = self.create_log_embed(
                "✏️ Nickname Changed",
                f"{after.mention}",
                0xFFAA00
            )
            embed.add_field(name="Before", value=before.nick or "None", inline=True)
            embed.add_field(name="After", value=after.nick or "None", inline=True)
            await log_channel.send(embed=embed)
        
        if before.roles != after.roles:
            added_roles = [role for role in after.roles if role not in before.roles]
            removed_roles = [role for role in before.roles if role not in after.roles]
            
            if added_roles:
                embed = self.create_log_embed(
                    "➕ Role Added",
                    f"{after.mention}",
                    0x00FF00
                )
                embed.add_field(name="Role", value=added_roles[0].mention, inline=True)
                await log_channel.send(embed=embed)
            
            if removed_roles:
                embed = self.create_log_embed(
                    "➖ Role Removed",
                    f"{after.mention}",
                    0xFF0000
                )
                embed.add_field(name="Role", value=removed_roles[0].mention, inline=True)
                await log_channel.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_message_delete(self, message):
        """Log deleted messages"""
        if message.author.bot:
            return
        
        log_channel = self.get_log_channel(message.guild)
        if not log_channel:
            return
        
        embed = self.create_log_embed(
            "🗑️ Message Deleted",
            f"Author: {message.author.mention}\nChannel: {message.channel.mention}",
            0xFF0000
        )
        
        if message.content:
            content = message.content[:1024]
            embed.add_field(name="Content", value=content, inline=False)
        
        if message.attachments:
            embed.add_field(name="Attachments", value=f"{len(message.attachments)} file(s)", inline=True)
        
        embed.set_footer(text=f"Message ID: {message.id}")
        
        await log_channel.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        """Log edited messages"""
        if before.author.bot or before.content == after.content:
            return
        
        log_channel = self.get_log_channel(after.guild)
        if not log_channel:
            return
        
        embed = self.create_log_embed(
            "✏️ Message Edited",
            f"Author: {after.author.mention}\nChannel: {after.channel.mention}",
            0xFFAA00
        )
        
        before_content = before.content[:512] if before.content else "No content"
        after_content = after.content[:512] if after.content else "No content"
        
        embed.add_field(name="Before", value=before_content, inline=False)
        embed.add_field(name="After", value=after_content, inline=False)
        embed.add_field(name="Jump to Message", value=f"[Click here]({after.jump_url})", inline=False)
        
        embed.set_footer(text=f"Message ID: {after.id}")
        
        await log_channel.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        """Log channel creation"""
        log_channel = self.get_log_channel(channel.guild)
        if not log_channel:
            return
        
        embed = self.create_log_embed(
            "➕ Channel Created",
            f"Channel: {channel.mention}\nType: {str(channel.type).title()}",
            0x00FF00
        )
        embed.add_field(name="Channel ID", value=channel.id, inline=True)
        
        await log_channel.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        """Log channel deletion"""
        log_channel = self.get_log_channel(channel.guild)
        if not log_channel or channel.id == log_channel.id:
            return
        
        embed = self.create_log_embed(
            "🗑️ Channel Deleted",
            f"Channel: #{channel.name}\nType: {str(channel.type).title()}",
            0xFF0000
        )
        embed.add_field(name="Channel ID", value=channel.id, inline=True)
        
        await log_channel.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        """Log role creation"""
        log_channel = self.get_log_channel(role.guild)
        if not log_channel:
            return
        
        embed = self.create_log_embed(
            "➕ Role Created",
            f"Role: {role.mention}",
            0x00FF00
        )
        embed.add_field(name="Role ID", value=role.id, inline=True)
        embed.add_field(name="Color", value=str(role.color), inline=True)
        
        await log_channel.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        """Log role deletion"""
        log_channel = self.get_log_channel(role.guild)
        if not log_channel:
            return
        
        embed = self.create_log_embed(
            "🗑️ Role Deleted",
            f"Role: {role.name}",
            0xFF0000
        )
        embed.add_field(name="Role ID", value=role.id, inline=True)
        embed.add_field(name="Members Had", value=len(role.members), inline=True)
        
        await log_channel.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        """Log voice state changes"""
        log_channel = self.get_log_channel(member.guild)
        if not log_channel:
            return
        
        if before.channel != after.channel:
            if before.channel is None:
                embed = self.create_log_embed(
                    "🔊 Voice Channel Join",
                    f"{member.mention} joined {after.channel.mention}",
                    0x00FF00
                )
                await log_channel.send(embed=embed)
            
            elif after.channel is None:
                embed = self.create_log_embed(
                    "🔇 Voice Channel Leave",
                    f"{member.mention} left {before.channel.mention}",
                    0xFF0000
                )
                await log_channel.send(embed=embed)
            
            else:
                embed = self.create_log_embed(
                    "🔄 Voice Channel Move",
                    f"{member.mention} moved from {before.channel.mention} to {after.channel.mention}",
                    0xFFAA00
                )
                await log_channel.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Logging(bot))
