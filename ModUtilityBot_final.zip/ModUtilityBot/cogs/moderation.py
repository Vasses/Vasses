import discord
from discord.ext import commands
from utils.permissions import is_moderator
from utils.embeds import success_embed, error_embed
from database import add_warning, get_warnings, clear_warnings, log_moderation_action
import datetime

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='kick')
    @is_moderator()
    async def kick(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Kick a member from the server"""
        if member.top_role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("You cannot kick this user!"))
        
        try:
            await member.kick(reason=f"Kicked by {ctx.author} | {reason}")
            await ctx.send(embed=success_embed(f"Kicked {member.mention} | Reason: {reason}"))
            await log_moderation_action(ctx.guild.id, "kick", ctx.author.id, member.id, reason)
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to kick this user!"))
    
    @commands.command(name='ban')
    @is_moderator()
    async def ban(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Ban a member from the server"""
        if member.top_role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("You cannot ban this user!"))
        
        try:
            await member.ban(reason=f"Banned by {ctx.author} | {reason}")
            await ctx.send(embed=success_embed(f"Banned {member.mention} | Reason: {reason}"))
            await log_moderation_action(ctx.guild.id, "ban", ctx.author.id, member.id, reason)
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to ban this user!"))
    
    @commands.command(name='unban')
    @is_moderator()
    async def unban(self, ctx, user_id: int, *, reason: str = "No reason provided"):
        """Unban a user from the server"""
        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user, reason=f"Unbanned by {ctx.author} | {reason}")
            await ctx.send(embed=success_embed(f"Unbanned {user.name} (ID: {user_id}) | Reason: {reason}"))
            await log_moderation_action(ctx.guild.id, "unban", ctx.author.id, user_id, reason)
        except discord.NotFound:
            await ctx.send(embed=error_embed("User not found or not banned!"))
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to unban users!"))
    
    @commands.command(name='timeout', aliases=['mute'])
    @is_moderator()
    async def timeout(self, ctx, member: discord.Member, duration: int, unit: str = "m", *, reason: str = "No reason provided"):
        """Timeout a member (e.g., vu!timeout @user 10 m reason)"""
        if member.top_role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("You cannot timeout this user!"))
        
        units = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400}
        if unit not in units:
            return await ctx.send(embed=error_embed("Invalid time unit! Use s, m, h, or d."))
        
        seconds = duration * units[unit]
        if seconds > 2419200:
            return await ctx.send(embed=error_embed("Maximum timeout duration is 28 days!"))
        
        try:
            until = discord.utils.utcnow() + datetime.timedelta(seconds=seconds)
            await member.timeout(until, reason=f"Timed out by {ctx.author} | {reason}")
            await ctx.send(embed=success_embed(f"Timed out {member.mention} for {duration}{unit} | Reason: {reason}"))
            await log_moderation_action(ctx.guild.id, "timeout", ctx.author.id, member.id, reason)
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to timeout this user!"))
    
    @commands.command(name='untimeout', aliases=['unmute'])
    @is_moderator()
    async def untimeout(self, ctx, member: discord.Member):
        """Remove timeout from a member"""
        try:
            await member.timeout(None)
            await ctx.send(embed=success_embed(f"Removed timeout from {member.mention}"))
            await log_moderation_action(ctx.guild.id, "untimeout", ctx.author.id, member.id)
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to remove timeout from this user!"))
    
    @commands.command(name='warn')
    @is_moderator()
    async def warn(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Warn a member"""
        await add_warning(member.id, ctx.guild.id, ctx.author.id, reason)
        await ctx.send(embed=success_embed(f"Warned {member.mention} | Reason: {reason}"))
        await log_moderation_action(ctx.guild.id, "warn", ctx.author.id, member.id, reason)
        
        try:
            await member.send(f"⚠️ You have been warned in {ctx.guild.name}\nReason: {reason}")
        except:
            pass
    
    @commands.command(name='warnings')
    @is_moderator()
    async def warnings(self, ctx, member: discord.Member):
        """Check warnings for a member"""
        warns = await get_warnings(member.id, ctx.guild.id)
        
        if not warns:
            return await ctx.send(embed=error_embed(f"{member.mention} has no warnings!"))
        
        embed = discord.Embed(title=f"Warnings for {member.name}", color=0xFFAA00)
        for warn_id, mod_id, reason, timestamp in warns:
            mod = await self.bot.fetch_user(mod_id)
            embed.add_field(
                name=f"Warning #{warn_id}",
                value=f"**Moderator:** {mod.mention}\n**Reason:** {reason}\n**Date:** {timestamp}",
                inline=False
            )
        
        await ctx.send(embed=embed)
    
    @commands.command(name='clearwarnings')
    @is_moderator()
    async def clearwarnings(self, ctx, member: discord.Member):
        """Clear all warnings for a member"""
        await clear_warnings(member.id, ctx.guild.id)
        await ctx.send(embed=success_embed(f"Cleared all warnings for {member.mention}"))
        await log_moderation_action(ctx.guild.id, "clearwarnings", ctx.author.id, member.id)
    
    @commands.command(name='clear', aliases=['purge'])
    @is_moderator()
    async def clear(self, ctx, amount: int):
        """Clear messages from the channel"""
        if amount < 1 or amount > 100:
            return await ctx.send(embed=error_embed("Amount must be between 1 and 100!"))
        
        try:
            deleted = await ctx.channel.purge(limit=amount + 1)
            msg = await ctx.send(embed=success_embed(f"Deleted {len(deleted) - 1} message(s)!"))
            await log_moderation_action(ctx.guild.id, "clear", ctx.author.id, None, f"Deleted {len(deleted) - 1} messages")
            await msg.delete(delay=3)
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to delete messages!"))
    
    @commands.command(name='slowmode')
    @is_moderator()
    async def slowmode(self, ctx, seconds: int):
        """Set slowmode for the channel"""
        if seconds < 0 or seconds > 21600:
            return await ctx.send(embed=error_embed("Slowmode must be between 0 and 21600 seconds!"))
        
        try:
            await ctx.channel.edit(slowmode_delay=seconds)
            if seconds == 0:
                await ctx.send(embed=success_embed("Slowmode disabled!"))
            else:
                await ctx.send(embed=success_embed(f"Slowmode set to {seconds} second(s)!"))
            await log_moderation_action(ctx.guild.id, "slowmode", ctx.author.id, None, f"Set to {seconds}s")
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to edit this channel!"))
    
    @commands.command(name='lock')
    @is_moderator()
    async def lock(self, ctx, channel: discord.TextChannel = None):
        """Lock a channel"""
        channel = channel or ctx.channel
        
        try:
            await channel.set_permissions(ctx.guild.default_role, send_messages=False)
            await ctx.send(embed=success_embed(f"🔒 Locked {channel.mention}"))
            await log_moderation_action(ctx.guild.id, "lock", ctx.author.id, None, f"Locked {channel.name}")
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to edit this channel!"))
    
    @commands.command(name='unlock')
    @is_moderator()
    async def unlock(self, ctx, channel: discord.TextChannel = None):
        """Unlock a channel"""
        channel = channel or ctx.channel
        
        try:
            await channel.set_permissions(ctx.guild.default_role, send_messages=None)
            await ctx.send(embed=success_embed(f"🔓 Unlocked {channel.mention}"))
            await log_moderation_action(ctx.guild.id, "unlock", ctx.author.id, None, f"Unlocked {channel.name}")
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to edit this channel!"))
    
    @commands.command(name='nick', aliases=['nickname'])
    @is_moderator()
    async def nick(self, ctx, member: discord.Member, *, nickname: str = None):
        """Change a member's nickname"""
        if member.top_role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("You cannot change this user's nickname!"))
        
        try:
            old_nick = member.display_name
            await member.edit(nick=nickname)
            if nickname:
                await ctx.send(embed=success_embed(f"Changed {member.mention}'s nickname to {nickname}"))
            else:
                await ctx.send(embed=success_embed(f"Reset {member.mention}'s nickname"))
            await log_moderation_action(ctx.guild.id, "nick", ctx.author.id, member.id, f"{old_nick} -> {nickname}")
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to change this user's nickname!"))
    
    @commands.command(name='addrole')
    @is_moderator()
    async def addrole(self, ctx, member: discord.Member, role: discord.Role):
        """Add a role to a member"""
        if role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("You cannot assign this role!"))
        
        if role in member.roles:
            return await ctx.send(embed=error_embed(f"{member.mention} already has this role!"))
        
        try:
            await member.add_roles(role)
            await ctx.send(embed=success_embed(f"Added {role.mention} to {member.mention}"))
            await log_moderation_action(ctx.guild.id, "addrole", ctx.author.id, member.id, f"Added {role.name}")
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to manage this role!"))
    
    @commands.command(name='removerole')
    @is_moderator()
    async def removerole(self, ctx, member: discord.Member, role: discord.Role):
        """Remove a role from a member"""
        if role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("You cannot manage this role!"))
        
        if role not in member.roles:
            return await ctx.send(embed=error_embed(f"{member.mention} doesn't have this role!"))
        
        try:
            await member.remove_roles(role)
            await ctx.send(embed=success_embed(f"Removed {role.mention} from {member.mention}"))
            await log_moderation_action(ctx.guild.id, "removerole", ctx.author.id, member.id, f"Removed {role.name}")
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to manage this role!"))
    
    @commands.command(name='hideall')
    @is_moderator()
    async def hideall(self, ctx, channel: discord.TextChannel = None):
        """Hide a channel from @everyone"""
        channel = channel or ctx.channel
        
        try:
            await channel.set_permissions(ctx.guild.default_role, view_channel=False)
            await ctx.send(embed=success_embed(f"👻 Hidden {channel.mention} from @everyone"))
            await log_moderation_action(ctx.guild.id, "hideall", ctx.author.id, None, f"Hidden {channel.name}")
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to edit this channel!"))
    
    @commands.command(name='showall')
    @is_moderator()
    async def showall(self, ctx, channel: discord.TextChannel = None):
        """Show a channel to @everyone"""
        channel = channel or ctx.channel
        
        try:
            await channel.set_permissions(ctx.guild.default_role, view_channel=None)
            await ctx.send(embed=success_embed(f"👁️ Showed {channel.mention} to @everyone"))
            await log_moderation_action(ctx.guild.id, "showall", ctx.author.id, None, f"Showed {channel.name}")
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to edit this channel!"))

async def setup(bot):
    await bot.add_cog(Moderation(bot))
