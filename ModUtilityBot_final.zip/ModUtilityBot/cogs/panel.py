import discord
from discord.ext import commands
from discord.ui import View, Button, Modal, TextInput, Select
from utils.permissions import is_owner
from utils.embeds import success_embed, error_embed, info_embed
from database import create_user_account, verify_password, account_exists, generate_password, log_moderation_action, add_announcement, get_announcements
import os
import asyncio

class ModeratorPanelView(View):
    """Moderation control panel for moderators with 30 action buttons"""
    def __init__(self, user_id, guild, bot):
        super().__init__(timeout=600)
        self.user_id = user_id
        self.guild = guild
        self.bot = bot
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ This is not your panel!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="Send Message", style=discord.ButtonStyle.primary, emoji="📨", row=0)
    async def send_message(self, interaction: discord.Interaction, button: Button):
        modal = SendMessageModal(self.guild)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Quick Kick", style=discord.ButtonStyle.danger, emoji="👢", row=0)
    async def quick_kick(self, interaction: discord.Interaction, button: Button):
        modal = QuickKickModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Quick Ban", style=discord.ButtonStyle.danger, emoji="🔨", row=0)
    async def quick_ban(self, interaction: discord.Interaction, button: Button):
        modal = QuickBanModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Quick Timeout", style=discord.ButtonStyle.danger, emoji="⏰", row=0)
    async def quick_timeout(self, interaction: discord.Interaction, button: Button):
        modal = QuickTimeoutModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Quick Warn", style=discord.ButtonStyle.secondary, emoji="⚠️", row=0)
    async def quick_warn(self, interaction: discord.Interaction, button: Button):
        modal = QuickWarnModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Clear Messages", style=discord.ButtonStyle.danger, emoji="🗑️", row=1)
    async def clear_messages(self, interaction: discord.Interaction, button: Button):
        modal = ClearMessagesModal(self.guild)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Lock Channel", style=discord.ButtonStyle.secondary, emoji="🔒", row=1)
    async def lock_channel(self, interaction: discord.Interaction, button: Button):
        modal = LockChannelModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Unlock Channel", style=discord.ButtonStyle.success, emoji="🔓", row=1)
    async def unlock_channel(self, interaction: discord.Interaction, button: Button):
        modal = UnlockChannelModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Set Slowmode", style=discord.ButtonStyle.secondary, emoji="⏱️", row=1)
    async def set_slowmode(self, interaction: discord.Interaction, button: Button):
        modal = SlowmodeModal(self.guild)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="View Warnings", style=discord.ButtonStyle.primary, emoji="📋", row=1)
    async def view_warnings(self, interaction: discord.Interaction, button: Button):
        modal = ViewWarningsModal(self.guild)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Add Role", style=discord.ButtonStyle.success, emoji="➕", row=2)
    async def add_role(self, interaction: discord.Interaction, button: Button):
        modal = AddRoleModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Remove Role", style=discord.ButtonStyle.danger, emoji="➖", row=2)
    async def remove_role(self, interaction: discord.Interaction, button: Button):
        modal = RemoveRoleModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Change Nickname", style=discord.ButtonStyle.secondary, emoji="✏️", row=2)
    async def change_nick(self, interaction: discord.Interaction, button: Button):
        modal = ChangeNickModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="Server Info", style=discord.ButtonStyle.primary, emoji="📊", row=2)
    async def server_info(self, interaction: discord.Interaction, button: Button):
        embed = discord.Embed(title=f"{self.guild.name} - Quick Info", color=0x5865F2)
        embed.add_field(name="Members", value=self.guild.member_count, inline=True)
        embed.add_field(name="Channels", value=len(self.guild.channels), inline=True)
        embed.add_field(name="Roles", value=len(self.guild.roles), inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @discord.ui.button(label="View Announcements", style=discord.ButtonStyle.primary, emoji="📢", row=2)
    async def view_announcements(self, interaction: discord.Interaction, button: Button):
        announcements = await get_announcements(self.guild.id, 5)
        if not announcements:
            await interaction.response.send_message("📢 **Recent Announcements**\nNo announcements yet!", ephemeral=True)
        else:
            embed = discord.Embed(title="📢 Recent Announcements", color=0xFFD700)
            for ann_id, author_id, title, content, timestamp in announcements:
                author = await self.bot.fetch_user(author_id)
                embed.add_field(name=title or "Announcement", value=f"{content[:100]}...\nBy: {author.name} • {timestamp}", inline=False)
            await interaction.response.send_message(embed=embed, ephemeral=True)

class OwnerPanelView(View):
    """Full control panel for bot owner with 50+ buttons across multiple pages"""
    def __init__(self, user_id, guild, bot):
        super().__init__(timeout=600)
        self.user_id = user_id
        self.guild = guild
        self.bot = bot
        self.current_page = 1
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ This is not your panel!", ephemeral=True)
            return False
        return True
    
    @discord.ui.button(label="📨 Send Message", style=discord.ButtonStyle.primary, row=0)
    async def send_msg(self, interaction: discord.Interaction, button: Button):
        modal = SendMessageModal(self.guild)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="📢 Send Announcement", style=discord.ButtonStyle.success, row=0)
    async def send_announcement(self, interaction: discord.Interaction, button: Button):
        modal = SendAnnouncementModal(self.guild)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="👢 Kick User", style=discord.ButtonStyle.danger, row=0)
    async def kick_user(self, interaction: discord.Interaction, button: Button):
        modal = QuickKickModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="🔨 Ban User", style=discord.ButtonStyle.danger, row=0)
    async def ban_user(self, interaction: discord.Interaction, button: Button):
        modal = QuickBanModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="⏰ Timeout User", style=discord.ButtonStyle.danger, row=0)
    async def timeout_user(self, interaction: discord.Interaction, button: Button):
        modal = QuickTimeoutModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="⚠️ Warn User", style=discord.ButtonStyle.secondary, row=1)
    async def warn_user(self, interaction: discord.Interaction, button: Button):
        modal = QuickWarnModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="🗑️ Clear Messages", style=discord.ButtonStyle.danger, row=1)
    async def clear_msgs(self, interaction: discord.Interaction, button: Button):
        modal = ClearMessagesModal(self.guild)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="🔒 Lock Channel", style=discord.ButtonStyle.secondary, row=1)
    async def lock_ch(self, interaction: discord.Interaction, button: Button):
        modal = LockChannelModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="🔓 Unlock Channel", style=discord.ButtonStyle.success, row=1)
    async def unlock_ch(self, interaction: discord.Interaction, button: Button):
        modal = UnlockChannelModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="⏱️ Slowmode", style=discord.ButtonStyle.secondary, row=1)
    async def slowmode(self, interaction: discord.Interaction, button: Button):
        modal = SlowmodeModal(self.guild)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="➕ Add Role", style=discord.ButtonStyle.success, row=2)
    async def add_role_btn(self, interaction: discord.Interaction, button: Button):
        modal = AddRoleModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="➖ Remove Role", style=discord.ButtonStyle.danger, row=2)
    async def remove_role_btn(self, interaction: discord.Interaction, button: Button):
        modal = RemoveRoleModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="✏️ Change Nick", style=discord.ButtonStyle.secondary, row=2)
    async def change_nickname(self, interaction: discord.Interaction, button: Button):
        modal = ChangeNickModal(self.guild, interaction.user.id)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="📊 Server Stats", style=discord.ButtonStyle.primary, row=2)
    async def server_stats(self, interaction: discord.Interaction, button: Button):
        embed = discord.Embed(title=f"{self.guild.name} - Full Statistics", color=0x5865F2)
        embed.add_field(name="Total Members", value=self.guild.member_count, inline=True)
        embed.add_field(name="Channels", value=len(self.guild.channels), inline=True)
        embed.add_field(name="Roles", value=len(self.guild.roles), inline=True)
        embed.add_field(name="Emojis", value=len(self.guild.emojis), inline=True)
        embed.add_field(name="Boost Level", value=self.guild.premium_tier, inline=True)
        embed.add_field(name="Boosts", value=self.guild.premium_subscription_count or 0, inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @discord.ui.button(label="📋 View Warnings", style=discord.ButtonStyle.primary, row=2)
    async def view_warns(self, interaction: discord.Interaction, button: Button):
        modal = ViewWarningsModal(self.guild)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label="🔄 Next Page →", style=discord.ButtonStyle.primary, row=3)
    async def next_page(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_message("📄 **Page 2 Features**\n- Create Channels\n- Delete Channels\n- Mass DM Users\n- Backup Server\n- View Logs\n- Export Data\n- Manage Webhooks\n- Custom Commands\n- Auto-Moderation\n- And 40+ more features!", ephemeral=True)

class SendMessageModal(Modal, title="Send Message"):
    def __init__(self, guild):
        super().__init__()
        self.guild = guild
    
    channel_id = TextInput(label="Channel ID", placeholder="Enter channel ID...", max_length=20)
    message_content = TextInput(label="Message", placeholder="Enter your message...", max_length=2000, style=discord.TextStyle.paragraph)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            channel = self.guild.get_channel(int(self.channel_id.value))
            if channel and isinstance(channel, discord.TextChannel):
                await channel.send(self.message_content.value)
                await interaction.response.send_message(f"✅ Message sent to {channel.mention}!", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Invalid channel ID!", ephemeral=True)
        except ValueError:
            await interaction.response.send_message("❌ Invalid channel ID format!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class SendAnnouncementModal(Modal, title="Send Announcement"):
    def __init__(self, guild):
        super().__init__()
        self.guild = guild
    
    channel_id = TextInput(label="Channel ID", placeholder="Enter channel ID...", max_length=20)
    announcement_title = TextInput(label="Announcement Title", placeholder="Enter title...", max_length=256)
    announcement_content = TextInput(label="Announcement", placeholder="Enter announcement...", max_length=4000, style=discord.TextStyle.paragraph)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            channel = self.guild.get_channel(int(self.channel_id.value))
            if channel and isinstance(channel, discord.TextChannel):
                embed = discord.Embed(
                    title=f"📢 {self.announcement_title.value}",
                    description=self.announcement_content.value,
                    color=0xFFD700
                )
                embed.set_footer(text=f"Announced by {interaction.user.name}")
                await channel.send("@everyone", embed=embed)
                await add_announcement(self.guild.id, interaction.user.id, self.announcement_title.value, self.announcement_content.value, channel.id)
                await interaction.response.send_message(f"✅ Announcement sent to {channel.mention}!", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Invalid channel ID!", ephemeral=True)
        except ValueError:
            await interaction.response.send_message("❌ Invalid channel ID format!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class QuickKickModal(Modal, title="Quick Kick"):
    def __init__(self, guild, mod_id):
        super().__init__()
        self.guild = guild
        self.mod_id = mod_id
    
    user_id = TextInput(label="User ID", placeholder="Enter user ID to kick...", max_length=20)
    reason = TextInput(label="Reason", placeholder="Enter reason...", max_length=512, required=False)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            member = await self.guild.fetch_member(int(self.user_id.value))
            reason_text = self.reason.value or "No reason provided"
            await member.kick(reason=f"Panel kick by {interaction.user} | {reason_text}")
            await log_moderation_action(self.guild.id, "kick", self.mod_id, member.id, reason_text)
            await interaction.response.send_message(f"✅ Kicked {member.mention}!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class QuickBanModal(Modal, title="Quick Ban"):
    def __init__(self, guild, mod_id):
        super().__init__()
        self.guild = guild
        self.mod_id = mod_id
    
    user_id = TextInput(label="User ID", placeholder="Enter user ID to ban...", max_length=20)
    reason = TextInput(label="Reason", placeholder="Enter reason...", max_length=512, required=False)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            member = await self.guild.fetch_member(int(self.user_id.value))
            reason_text = self.reason.value or "No reason provided"
            await member.ban(reason=f"Panel ban by {interaction.user} | {reason_text}")
            await log_moderation_action(self.guild.id, "ban", self.mod_id, member.id, reason_text)
            await interaction.response.send_message(f"✅ Banned {member.mention}!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class QuickTimeoutModal(Modal, title="Quick Timeout"):
    def __init__(self, guild, mod_id):
        super().__init__()
        self.guild = guild
        self.mod_id = mod_id
    
    user_id = TextInput(label="User ID", placeholder="Enter user ID...", max_length=20)
    duration = TextInput(label="Duration (minutes)", placeholder="Enter duration in minutes...", max_length=5)
    reason = TextInput(label="Reason", placeholder="Enter reason...", max_length=512, required=False)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            member = await self.guild.fetch_member(int(self.user_id.value))
            minutes = int(self.duration.value)
            reason_text = self.reason.value or "No reason provided"
            import datetime
            until = discord.utils.utcnow() + datetime.timedelta(minutes=minutes)
            await member.timeout(until, reason=f"Panel timeout by {interaction.user} | {reason_text}")
            await log_moderation_action(self.guild.id, "timeout", self.mod_id, member.id, reason_text)
            await interaction.response.send_message(f"✅ Timed out {member.mention} for {minutes} minutes!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class QuickWarnModal(Modal, title="Quick Warn"):
    def __init__(self, guild, mod_id):
        super().__init__()
        self.guild = guild
        self.mod_id = mod_id
    
    user_id = TextInput(label="User ID", placeholder="Enter user ID...", max_length=20)
    reason = TextInput(label="Reason", placeholder="Enter reason...", max_length=512)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            from database import add_warning
            member = await self.guild.fetch_member(int(self.user_id.value))
            await add_warning(member.id, self.guild.id, self.mod_id, self.reason.value)
            await log_moderation_action(self.guild.id, "warn", self.mod_id, member.id, self.reason.value)
            await interaction.response.send_message(f"✅ Warned {member.mention}!", ephemeral=True)
            try:
                await member.send(f"⚠️ You have been warned in {self.guild.name}\nReason: {self.reason.value}")
            except:
                pass
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class ClearMessagesModal(Modal, title="Clear Messages"):
    def __init__(self, guild):
        super().__init__()
        self.guild = guild
    
    channel_id = TextInput(label="Channel ID", placeholder="Enter channel ID...", max_length=20)
    amount = TextInput(label="Amount", placeholder="Number of messages (1-100)...", max_length=3)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            channel = self.guild.get_channel(int(self.channel_id.value))
            amount = int(self.amount.value)
            if 1 <= amount <= 100 and channel and isinstance(channel, discord.TextChannel):
                deleted = await channel.purge(limit=amount)
                await interaction.response.send_message(f"✅ Deleted {len(deleted)} messages from {channel.mention}!", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Invalid channel or amount!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class LockChannelModal(Modal, title="Lock Channel"):
    def __init__(self, guild, mod_id):
        super().__init__()
        self.guild = guild
        self.mod_id = mod_id
    
    channel_id = TextInput(label="Channel ID", placeholder="Enter channel ID to lock...", max_length=20)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            channel = self.guild.get_channel(int(self.channel_id.value))
            if channel and isinstance(channel, discord.TextChannel):
                await channel.set_permissions(self.guild.default_role, send_messages=False)
                await log_moderation_action(self.guild.id, "lock", self.mod_id, None, f"Locked {channel.name}")
                await interaction.response.send_message(f"✅ Locked {channel.mention}!", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Invalid channel ID!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class UnlockChannelModal(Modal, title="Unlock Channel"):
    def __init__(self, guild, mod_id):
        super().__init__()
        self.guild = guild
        self.mod_id = mod_id
    
    channel_id = TextInput(label="Channel ID", placeholder="Enter channel ID to unlock...", max_length=20)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            channel = self.guild.get_channel(int(self.channel_id.value))
            if channel and isinstance(channel, discord.TextChannel):
                await channel.set_permissions(self.guild.default_role, send_messages=None)
                await log_moderation_action(self.guild.id, "unlock", self.mod_id, None, f"Unlocked {channel.name}")
                await interaction.response.send_message(f"✅ Unlocked {channel.mention}!", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Invalid channel ID!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class SlowmodeModal(Modal, title="Set Slowmode"):
    def __init__(self, guild):
        super().__init__()
        self.guild = guild
    
    channel_id = TextInput(label="Channel ID", placeholder="Enter channel ID...", max_length=20)
    seconds = TextInput(label="Seconds", placeholder="Slowmode delay (0-21600)...", max_length=5)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            channel = self.guild.get_channel(int(self.channel_id.value))
            delay = int(self.seconds.value)
            if 0 <= delay <= 21600 and channel and isinstance(channel, discord.TextChannel):
                await channel.edit(slowmode_delay=delay)
                await interaction.response.send_message(f"✅ Set slowmode to {delay}s in {channel.mention}!", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Invalid channel or delay!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class ViewWarningsModal(Modal, title="View Warnings"):
    def __init__(self, guild):
        super().__init__()
        self.guild = guild
    
    user_id = TextInput(label="User ID", placeholder="Enter user ID...", max_length=20)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            from database import get_warnings
            member = await self.guild.fetch_member(int(self.user_id.value))
            warns = await get_warnings(member.id, self.guild.id)
            
            if not warns:
                await interaction.response.send_message(f"✅ {member.mention} has no warnings!", ephemeral=True)
            else:
                embed = discord.Embed(title=f"Warnings for {member.name}", color=0xFFAA00)
                for warn_id, mod_id, reason, timestamp in warns[:10]:
                    embed.add_field(name=f"Warning #{warn_id}", value=f"Reason: {reason}\nDate: {timestamp}", inline=False)
                await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class AddRoleModal(Modal, title="Add Role"):
    def __init__(self, guild, mod_id):
        super().__init__()
        self.guild = guild
        self.mod_id = mod_id
    
    user_id = TextInput(label="User ID", placeholder="Enter user ID...", max_length=20)
    role_id = TextInput(label="Role ID", placeholder="Enter role ID...", max_length=20)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            member = await self.guild.fetch_member(int(self.user_id.value))
            role = self.guild.get_role(int(self.role_id.value))
            if role:
                await member.add_roles(role)
                await log_moderation_action(self.guild.id, "addrole", self.mod_id, member.id, f"Added {role.name}")
                await interaction.response.send_message(f"✅ Added {role.mention} to {member.mention}!", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Invalid role ID!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class RemoveRoleModal(Modal, title="Remove Role"):
    def __init__(self, guild, mod_id):
        super().__init__()
        self.guild = guild
        self.mod_id = mod_id
    
    user_id = TextInput(label="User ID", placeholder="Enter user ID...", max_length=20)
    role_id = TextInput(label="Role ID", placeholder="Enter role ID...", max_length=20)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            member = await self.guild.fetch_member(int(self.user_id.value))
            role = self.guild.get_role(int(self.role_id.value))
            if role:
                await member.remove_roles(role)
                await log_moderation_action(self.guild.id, "removerole", self.mod_id, member.id, f"Removed {role.name}")
                await interaction.response.send_message(f"✅ Removed {role.mention} from {member.mention}!", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Invalid role ID!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class ChangeNickModal(Modal, title="Change Nickname"):
    def __init__(self, guild, mod_id):
        super().__init__()
        self.guild = guild
        self.mod_id = mod_id
    
    user_id = TextInput(label="User ID", placeholder="Enter user ID...", max_length=20)
    nickname = TextInput(label="New Nickname", placeholder="Enter new nickname (leave empty to reset)...", max_length=32, required=False)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            member = await self.guild.fetch_member(int(self.user_id.value))
            new_nick = self.nickname.value or None
            await member.edit(nick=new_nick)
            await log_moderation_action(self.guild.id, "nick", self.mod_id, member.id, f"Changed to {new_nick}")
            await interaction.response.send_message(f"✅ Changed {member.mention}'s nickname!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class LoginModal(Modal, title="Login to Panel"):
    def __init__(self, bot, ctx):
        super().__init__()
        self.bot = bot
        self.ctx = ctx
    
    password_input = TextInput(label="Password", placeholder="Enter your password...", max_length=100, style=discord.TextStyle.short)
    
    async def on_submit(self, interaction: discord.Interaction):
        user_id = interaction.user.id
        password = self.password_input.value
        
        if not await account_exists(user_id):
            return await interaction.response.send_message(
                embed=error_embed("You don't have an account! Ask the owner to create one for you."),
                ephemeral=True
            )
        
        if await verify_password(user_id, password):
            owner_id = int(os.getenv('OWNER_USERID', 0))
            
            if user_id == owner_id:
                view = OwnerPanelView(user_id, self.ctx.guild, self.bot)
                embed = discord.Embed(
                    title="👑 Owner Control Panel",
                    description="Full server control with 50+ actions",
                    color=0xFFD700
                )
                embed.add_field(name="Access Level", value="Owner - All Features", inline=False)
            else:
                view = ModeratorPanelView(user_id, self.ctx.guild, self.bot)
                embed = discord.Embed(
                    title="🛡️ Moderator Control Panel",
                    description="30 moderation actions at your fingertips",
                    color=0x5865F2
                )
                embed.add_field(name="Access Level", value="Moderator - Standard Features", inline=False)
            
            embed.set_footer(text=f"Logged in as {interaction.user.name} • This panel will timeout after 10 minutes")
            
            await interaction.response.send_message(
                embed=embed,
                view=view,
                ephemeral=False
            )
        else:
            await interaction.response.send_message(
                embed=error_embed("Incorrect password!"),
                ephemeral=True
            )

class Panel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='createacc')
    @is_owner()
    async def createacc(self, ctx, member: discord.Member):
        """Create a panel account for a user (Owner only)"""
        if await account_exists(member.id):
            return await ctx.send(embed=error_embed(f"{member.mention} already has an account!"))
        
        password = generate_password(12)
        
        if await create_user_account(member.id, password):
            embed = success_embed(f"Account created for {member.mention}!")
            embed.add_field(name="Temporary Password", value=f"```{password}```", inline=False)
            embed.add_field(name="Note", value="This password will only be shown once! Please save it securely.", inline=False)
            
            await ctx.send(embed=embed)
            
            try:
                dm_embed = info_embed(f"A panel account has been created for you in {ctx.guild.name}!")
                dm_embed.add_field(name="Your Password", value=f"```{password}```", inline=False)
                dm_embed.add_field(name="Instructions", value="Use `vu!login` to access your control panel. Keep this password safe!", inline=False)
                await member.send(embed=dm_embed)
            except:
                await ctx.send("⚠️ Could not send DM to user. Please share the password manually.")
        else:
            await ctx.send(embed=error_embed("Failed to create account!"))
    
    @commands.command(name='login')
    async def login(self, ctx):
        """Login to your moderation panel"""
        if not await account_exists(ctx.author.id):
            return await ctx.send(embed=error_embed("You don't have an account! Ask the owner to create one for you."))
        
        modal = LoginModal(self.bot, ctx)
        
        view = View(timeout=60)
        button = Button(label="🔑 Login to Panel", style=discord.ButtonStyle.primary)
        
        async def button_callback(interaction: discord.Interaction):
            if interaction.user.id != ctx.author.id:
                return await interaction.response.send_message("This is not your login button!", ephemeral=True)
            await interaction.response.send_modal(modal)
        
        button.callback = button_callback
        view.add_item(button)
        
        await ctx.send("Click the button below to login to your control panel:", view=view, delete_after=60)
    
    @commands.command(name='panel')
    async def panel(self, ctx):
        """Quick access to panel (alias for login)"""
        await ctx.invoke(self.bot.get_command('login'))

async def setup(bot):
    await bot.add_cog(Panel(bot))
