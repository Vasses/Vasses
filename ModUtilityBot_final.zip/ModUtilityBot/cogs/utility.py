import discord
from discord.ext import commands
from utils.permissions import is_moderator
from utils.embeds import info_embed, error_embed
import datetime
import platform

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.start_time = datetime.datetime.utcnow()
    
    
    @commands.command(name='ping')
    async def ping(self, ctx):
        """Show bot latency and uptime."""
        latency_ms = round(self.bot.latency * 1000)
        uptime_delta = datetime.datetime.utcnow() - self.start_time
        # Format uptime as D days, HH:MM:SS
        days = uptime_delta.days
        hours, remainder = divmod(uptime_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        uptime_parts = []
        if days:
            uptime_parts.append(f"{days}d")
        uptime_parts.append(f"{hours:02d}h")
        uptime_parts.append(f"{minutes:02d}m")
        uptime_parts.append(f"{seconds:02d}s")
        uptime_str = ' '.join(uptime_parts)
        message = f"**Latency:** {latency_ms} ms\n**Uptime:** {uptime_str}"
        await ctx.send

@commands.command(name='keeponline')
@commands.has_permissions(manage_guild=True)
async def keeponline(self, ctx):
    """Keep the bot active by sending messages every 10 seconds."""
    if hasattr(self, 'keep_task') and self.keep_task and not self.keep_task.done():
        await ctx.send(embed=info_embed("Already keeping online.", title="⚠️ Warning"))
        return

    self.keep_running = True
    self.keep_channel = ctx.channel

    messages = [
        "✅ I’m still here!",
        "🛰️ Staying connected…",
        "⚡ Keeping online!",
        "💡 Not going anywhere!",
        "🧠 Awake and watching!"
    ]

    async def keep_loop():
        import asyncio, random
        while self.keep_running:
            try:
                await self.keep_channel.send(random.choice(messages))
                await asyncio.sleep(10)
            except Exception as e:
                print(f"KeepOnline error: {e}")
                break

    import asyncio
    self.keep_task = asyncio.create_task(keep_loop())
    await ctx.send(embed=success_embed("Now keeping online!", title="✅ Activated"))

@commands.command(name='keepoffline')
@commands.has_permissions(manage_guild=True)
async def keepoffline(self, ctx):
    """Stop the keep-online loop."""
    if hasattr(self, 'keep_running') and self.keep_running:
        self.keep_running = False
        await ctx.send(embed=warning_embed("Stopped keep-online mode.", title="🛑 Deactivated"))
    else:
        await ctx.send(embed=info_embed("Keep-online mode wasn’t active.", title="ℹ️ Info"))

@commands.command(name='dm')
@commands.has_permissions(manage_messages=True)
async def dm(self, ctx, user: discord.User, *, content: str):
    """Send a direct message to a specific user (mention or user ID)."""
    try:
        await user.send(content)
        await ctx.send(embed=success_embed(f"DM sent to {user.mention}", title="📩 Sent"))
    except Exception as e:
        await ctx.send(embed=error_embed(f"Could not send DM: {e}", title="❌ Failed"))
(embed=info_embed(message, title="🏓 Pong!"))
@commands.command(name='help')
    async def help(self, ctx):
        """Display all available commands"""
        embed = discord.Embed(
            title="📚 Bot Commands",
            description="Here are all available commands for this bot:",
            color=0x5865F2
        )
        
        embed.add_field(
            name="🛡️ Moderation Commands",
            value=(
                "`kick`, `ban`, `unban`, `timeout`, `untimeout`, `warn`, `warnings`, "
                "`clearwarnings`, `clear`, `slowmode`, `lock`, `unlock`, `nick`, "
                "`addrole`, `removerole`, `hideall`, `showall`"
            ),
            inline=False
        )
        
        embed.add_field(
            name="🔧 Utility Commands",
            value="`help`, `ping`, `uptime`, `serverinfo`, `userinfo`, `avatar`, `roleinfo`, `channelinfo`",
            inline=False
        )
        
        embed.add_field(
            name="🎤 Voice Commands",
            value="`move`, `askmove`, `disconnect`, `voiceinfo`",
            inline=False
        )
        
        embed.add_field(
            name="🎨 Panel Commands",
            value="`createacc`, `login`, `panel`",
            inline=False
        )
        
        embed.set_footer(text="Use vu! before each command • Moderation commands require moderator role")
        await ctx.send(embed=embed)
    
    @commands.command(name='ping')
    async def ping(self, ctx):
        """Check bot latency"""
        latency = round(self.bot.latency * 1000)
        embed = info_embed(f"🏓 Pong! Latency: {latency}ms", "Bot Status")
        await ctx.send(embed=embed)
    
    @commands.command(name='uptime')
    async def uptime(self, ctx):
        """Check bot uptime"""
        uptime = datetime.datetime.utcnow() - self.start_time
        hours, remainder = divmod(int(uptime.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days, hours = divmod(hours, 24)
        
        uptime_str = f"{days}d {hours}h {minutes}m {seconds}s"
        embed = info_embed(f"⏰ Bot has been online for: {uptime_str}", "Uptime")
        await ctx.send(embed=embed)
    
    @commands.command(name='serverinfo')
    async def serverinfo(self, ctx):
        """Get information about the server"""
        guild = ctx.guild
        
        embed = discord.Embed(title=f"{guild.name} - Server Information", color=0x5865F2)
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        embed.add_field(name="👑 Owner", value=guild.owner.mention, inline=True)
        embed.add_field(name="📅 Created", value=guild.created_at.strftime("%B %d, %Y"), inline=True)
        embed.add_field(name="🆔 Server ID", value=guild.id, inline=True)
        
        embed.add_field(name="👥 Members", value=guild.member_count, inline=True)
        embed.add_field(name="💬 Channels", value=len(guild.channels), inline=True)
        embed.add_field(name="🎭 Roles", value=len(guild.roles), inline=True)
        
        embed.add_field(name="😀 Emojis", value=len(guild.emojis), inline=True)
        embed.add_field(name="🚀 Boost Level", value=guild.premium_tier, inline=True)
        embed.add_field(name="💎 Boosts", value=guild.premium_subscription_count or 0, inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='userinfo')
    async def userinfo(self, ctx, member: discord.Member = None):
        """Get information about a user"""
        member = member or ctx.author
        
        embed = discord.Embed(title=f"{member.name} - User Information", color=member.color)
        embed.set_thumbnail(url=member.display_avatar.url)
        
        embed.add_field(name="👤 Username", value=str(member), inline=True)
        embed.add_field(name="🆔 User ID", value=member.id, inline=True)
        embed.add_field(name="📝 Nickname", value=member.nick or "None", inline=True)
        
        embed.add_field(name="📅 Account Created", value=member.created_at.strftime("%B %d, %Y"), inline=True)
        embed.add_field(name="📥 Joined Server", value=member.joined_at.strftime("%B %d, %Y"), inline=True)
        embed.add_field(name="🎭 Roles", value=len(member.roles) - 1, inline=True)
        
        if member.premium_since:
            embed.add_field(name="💎 Boosting Since", value=member.premium_since.strftime("%B %d, %Y"), inline=True)
        
        roles = [role.mention for role in member.roles[1:][:10]]
        if roles:
            embed.add_field(name="Top Roles", value=" ".join(roles[:10]), inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='avatar')
    async def avatar(self, ctx, member: discord.Member = None):
        """Get a user's avatar"""
        member = member or ctx.author
        
        embed = discord.Embed(title=f"{member.name}'s Avatar", color=member.color)
        embed.set_image(url=member.display_avatar.url)
        embed.add_field(name="Download", value=f"[Click here]({member.display_avatar.url})")
        
        await ctx.send(embed=embed)
    
    @commands.command(name='roleinfo')
    @is_moderator()
    async def roleinfo(self, ctx, role: discord.Role):
        """Get information about a role"""
        embed = discord.Embed(title=f"Role Information - {role.name}", color=role.color)
        
        embed.add_field(name="🆔 Role ID", value=role.id, inline=True)
        embed.add_field(name="🎨 Color", value=str(role.color), inline=True)
        embed.add_field(name="👥 Members", value=len(role.members), inline=True)
        
        embed.add_field(name="📍 Position", value=role.position, inline=True)
        embed.add_field(name="📌 Mentionable", value="Yes" if role.mentionable else "No", inline=True)
        embed.add_field(name="🔒 Hoisted", value="Yes" if role.hoist else "No", inline=True)
        
        embed.add_field(name="📅 Created", value=role.created_at.strftime("%B %d, %Y"), inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='channelinfo')
    @is_moderator()
    async def channelinfo(self, ctx, channel: discord.TextChannel = None):
        """Get information about a channel"""
        channel = channel or ctx.channel
        
        embed = discord.Embed(title=f"Channel Information - #{channel.name}", color=0x5865F2)
        
        embed.add_field(name="🆔 Channel ID", value=channel.id, inline=True)
        embed.add_field(name="📍 Position", value=channel.position, inline=True)
        embed.add_field(name="🔞 NSFW", value="Yes" if channel.nsfw else "No", inline=True)
        
        if channel.topic:
            embed.add_field(name="📝 Topic", value=channel.topic, inline=False)
        
        embed.add_field(name="⏱️ Slowmode", value=f"{channel.slowmode_delay}s" if channel.slowmode_delay else "Disabled", inline=True)
        embed.add_field(name="📅 Created", value=channel.created_at.strftime("%B %d, %Y"), inline=True)
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Utility(bot))