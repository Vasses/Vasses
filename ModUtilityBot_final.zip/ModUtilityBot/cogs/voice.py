import discord
from discord.ext import commands
from utils.permissions import is_moderator
from utils.embeds import success_embed, error_embed, info_embed
from database import log_moderation_action
import asyncio

class Voice(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.pending_moves = {}
    
    @commands.command(name='move')
    @is_moderator()
    async def move(self, ctx, member: discord.Member, channel: discord.VoiceChannel):
        """Move a user to another voice channel"""
        if not member.voice:
            return await ctx.send(embed=error_embed(f"{member.mention} is not in a voice channel!"))
        
        try:
            await member.move_to(channel)
            await ctx.send(embed=success_embed(f"Moved {member.mention} to {channel.mention}"))
            await log_moderation_action(ctx.guild.id, "move", ctx.author.id, member.id, f"Moved to {channel.name}")
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to move this user!"))
        except discord.HTTPException:
            await ctx.send(embed=error_embed("Failed to move the user!"))
    
    @commands.command(name='askmove')
    @is_moderator()
    async def askmove(self, ctx, member: discord.Member, channel: discord.VoiceChannel):
        """Ask a user if they want to be moved to another voice channel"""
        if not member.voice:
            return await ctx.send(embed=error_embed(f"{member.mention} is not in a voice channel!"))
        
        embed = discord.Embed(
            title="🎤 Voice Channel Move Request",
            description=f"{ctx.author.mention} would like to move you to {channel.mention}",
            color=0x5865F2
        )
        embed.add_field(name="Instructions", value="Reply with **Yes** or **No** in this DM within 60 seconds.")
        
        try:
            await member.send(embed=embed)
        except discord.Forbidden:
            return await ctx.send(embed=error_embed(f"Cannot send DM to {member.mention}! They may have DMs disabled."))
        
        await ctx.send(embed=info_embed(f"Move request sent to {member.mention}. Waiting for response..."))
        
        def check(m):
            return m.author.id == member.id and isinstance(m.channel, discord.DMChannel) and m.content.lower() in ['yes', 'no']
        
        try:
            msg = await self.bot.wait_for('message', check=check, timeout=60.0)
            
            if msg.content.lower() == 'yes':
                try:
                    await member.move_to(channel)
                    await member.send(embed=success_embed(f"You have been moved to {channel.mention}"))
                    await ctx.send(embed=success_embed(f"{member.mention} accepted and was moved to {channel.mention}"))
                    await log_moderation_action(ctx.guild.id, "askmove", ctx.author.id, member.id, f"Accepted move to {channel.name}")
                except discord.Forbidden:
                    await ctx.send(embed=error_embed("I don't have permission to move this user!"))
            else:
                await member.send(embed=info_embed("Move request declined."))
                await ctx.send(embed=info_embed(f"{member.mention} declined the move request."))
                
        except asyncio.TimeoutError:
            await member.send(embed=error_embed("Move request timed out (no response within 60 seconds)."))
            await ctx.send(embed=error_embed(f"{member.mention} did not respond in time."))
    
    @commands.command(name='disconnect')
    @is_moderator()
    async def disconnect(self, ctx, member: discord.Member):
        """Disconnect a user from voice channel"""
        if not member.voice:
            return await ctx.send(embed=error_embed(f"{member.mention} is not in a voice channel!"))
        
        try:
            await member.move_to(None)
            await ctx.send(embed=success_embed(f"Disconnected {member.mention} from voice"))
            await log_moderation_action(ctx.guild.id, "disconnect", ctx.author.id, member.id)
        except discord.Forbidden:
            await ctx.send(embed=error_embed("I don't have permission to disconnect this user!"))
    
    @commands.command(name='voiceinfo')
    async def voiceinfo(self, ctx, channel: discord.VoiceChannel = None):
        """Get information about a voice channel"""
        if not channel:
            if ctx.author.voice:
                channel = ctx.author.voice.channel
            else:
                return await ctx.send(embed=error_embed("You must specify a voice channel or be in one!"))
        
        embed = discord.Embed(title=f"🎤 {channel.name}", color=0x5865F2)
        
        embed.add_field(name="🆔 Channel ID", value=channel.id, inline=True)
        embed.add_field(name="👥 Members", value=len(channel.members), inline=True)
        embed.add_field(name="📊 User Limit", value=channel.user_limit if channel.user_limit else "Unlimited", inline=True)
        
        embed.add_field(name="🔊 Bitrate", value=f"{channel.bitrate // 1000}kbps", inline=True)
        embed.add_field(name="🌍 Region", value=str(channel.rtc_region or "Automatic"), inline=True)
        
        if channel.members:
            members_list = ", ".join([m.mention for m in channel.members[:10]])
            if len(channel.members) > 10:
                members_list += f" and {len(channel.members) - 10} more..."
            embed.add_field(name="Connected Users", value=members_list, inline=False)
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Voice(bot))
