import aiosqlite
import bcrypt
import secrets
from typing import Optional, Dict, Any

DATABASE_PATH = "bot_data.db"

async def init_database():
    """Initialize the database with all required tables"""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        # User accounts table for panel system
        await db.execute("""
            CREATE TABLE IF NOT EXISTS user_accounts (
                user_id INTEGER PRIMARY KEY,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # User panel configurations
        await db.execute("""
            CREATE TABLE IF NOT EXISTS panel_configs (
                user_id INTEGER PRIMARY KEY,
                config_data TEXT,
                FOREIGN KEY (user_id) REFERENCES user_accounts(user_id)
            )
        """)
        
        # Warnings system
        await db.execute("""
            CREATE TABLE IF NOT EXISTS warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                guild_id INTEGER NOT NULL,
                moderator_id INTEGER NOT NULL,
                reason TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Moderation logs
        await db.execute("""
            CREATE TABLE IF NOT EXISTS mod_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                action_type TEXT NOT NULL,
                moderator_id INTEGER NOT NULL,
                target_id INTEGER,
                reason TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Announcements
        await db.execute("""
            CREATE TABLE IF NOT EXISTS announcements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                author_id INTEGER NOT NULL,
                title TEXT,
                content TEXT NOT NULL,
                channel_id INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        await db.commit()

def hash_password(password: str) -> str:
    """Hash a password using bcrypt with salt"""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

async def create_user_account(user_id: int, password: str) -> bool:
    """Create a new user account with hashed password"""
    try:
        async with aiosqlite.connect(DATABASE_PATH) as db:
            password_hash = hash_password(password)
            await db.execute(
                "INSERT INTO user_accounts (user_id, password_hash) VALUES (?, ?)",
                (user_id, password_hash)
            )
            await db.commit()
            return True
    except aiosqlite.IntegrityError:
        return False

async def verify_password(user_id: int, password: str) -> bool:
    """Verify a user's password"""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            "SELECT password_hash FROM user_accounts WHERE user_id = ?",
            (user_id,)
        )
        row = await cursor.fetchone()
        if not row:
            return False
        return bcrypt.checkpw(password.encode('utf-8'), row[0].encode('utf-8'))

async def account_exists(user_id: int) -> bool:
    """Check if a user account exists"""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            "SELECT 1 FROM user_accounts WHERE user_id = ?",
            (user_id,)
        )
        return await cursor.fetchone() is not None

async def add_warning(user_id: int, guild_id: int, moderator_id: int, reason: str = None):
    """Add a warning to a user"""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            "INSERT INTO warnings (user_id, guild_id, moderator_id, reason) VALUES (?, ?, ?, ?)",
            (user_id, guild_id, moderator_id, reason)
        )
        await db.commit()

async def get_warnings(user_id: int, guild_id: int) -> list:
    """Get all warnings for a user in a guild"""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            "SELECT id, moderator_id, reason, created_at FROM warnings WHERE user_id = ? AND guild_id = ?",
            (user_id, guild_id)
        )
        return await cursor.fetchall()

async def clear_warnings(user_id: int, guild_id: int):
    """Clear all warnings for a user in a guild"""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            "DELETE FROM warnings WHERE user_id = ? AND guild_id = ?",
            (user_id, guild_id)
        )
        await db.commit()

async def log_moderation_action(guild_id: int, action_type: str, moderator_id: int, target_id: int = None, reason: str = None):
    """Log a moderation action"""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            "INSERT INTO mod_logs (guild_id, action_type, moderator_id, target_id, reason) VALUES (?, ?, ?, ?, ?)",
            (guild_id, action_type, moderator_id, target_id, reason)
        )
        await db.commit()

def generate_password(length: int = 12) -> str:
    """Generate a random secure password"""
    return secrets.token_urlsafe(length)[:length]

async def add_announcement(guild_id: int, author_id: int, title: str, content: str, channel_id: int = None):
    """Store an announcement"""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            "INSERT INTO announcements (guild_id, author_id, title, content, channel_id) VALUES (?, ?, ?, ?, ?)",
            (guild_id, author_id, title, content, channel_id)
        )
        await db.commit()

async def get_announcements(guild_id: int, limit: int = 10) -> list:
    """Get recent announcements for a guild"""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            "SELECT id, author_id, title, content, timestamp FROM announcements WHERE guild_id = ? ORDER BY timestamp DESC LIMIT ?",
            (guild_id, limit)
        )
        return await cursor.fetchall()
