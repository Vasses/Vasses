import discord
from discord.ext import commands
import os
from dotenv import load_dotenv
import asyncio
from database import init_database

load_dotenv()

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.presences = True
intents.guilds = True
intents.voice_states = True

bot = commands.Bot(command_prefix='vu!', intents=intents, help_command=None)

@bot.event
async def on_ready():
    print(f'✅ {bot.user.name} is now online!')
    print(f'Bot ID: {bot.user.id}')
    print(f'Connected to {len(bot.guilds)} guild(s)')
    print('─' * 40)
    
    await init_database()
    print('✅ Database initialized')
    
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching,
        name="vu!help | Moderation Bot"
    ))

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.MissingPermissions):
        await ctx.send("❌ You don't have permission to use this command!")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"❌ Missing required argument: {error.param.name}")
    elif isinstance(error, commands.BadArgument):
        await ctx.send("❌ Invalid argument provided!")
    elif isinstance(error, commands.CheckFailure):
        pass
    else:
        print(f'Error: {error}')
        await ctx.send(f"❌ An error occurred: {str(error)}")

async def load_cogs():
    """Load all cog files"""
    cogs = [
        'cogs.moderation',
        'cogs.utility',
        'cogs.voice',
        'cogs.panel',
        'cogs.logging'
    ]
    
    for cog in cogs:
        try:
            await bot.load_extension(cog)
            print(f'✅ Loaded {cog}')
        except Exception as e:
            print(f'❌ Failed to load {cog}: {e}')

async def main():
    async with bot:
        await load_cogs()
        token = os.getenv('DISCORD_TOKEN')
        if not token:
            print('❌ Error: DISCORD_TOKEN not found in environment variables!')
            print('Please create a .env file with your Discord bot token.')
            return
        await bot.start(token)

if __name__ == '__main__':
    asyncio.run(main())
