# Discord Moderation Bot

## Overview
A comprehensive Discord bot with the prefix `vu!` featuring extensive moderation tools, utility commands, voice channel management, a custom panel system with password-protected accounts, and comprehensive logging.

## Recent Changes
- October 26, 2025: Initial bot creation with all core features implemented
- Implemented 50+ commands across moderation, utility, and voice categories
- Created interactive embed panel system with 30+ customization buttons
- Added comprehensive logging for all server events

## Features

### Moderation Commands (Moderator Role Required)
- **User Management**: kick, ban, unban, timeout, untimeout, warn, warnings, clearwarnings
- **Message Management**: clear/purge messages
- **Channel Management**: slowmode, lock, unlock, hideall, showall
- **Member Management**: nick (nickname), addrole, removerole

### Utility Commands
- **Information**: help, serverinfo, userinfo, avatar, roleinfo, channelinfo
- **Bot Status**: ping, uptime

### Voice Commands (Moderator Role Required)
- **move**: Move a user to another voice channel directly
- **askmove**: Send a DM asking user consent before moving them
- **disconnect**: Disconnect a user from voice
- **voiceinfo**: Get information about a voice channel

### Panel System (Moderation Control Panel)
- **createacc** (Owner Only): Create password-protected panel accounts for users
- **login**: Login to your personal moderation control panel (shows in channel)
- **Moderator Panel Features** (30 buttons):
  - Send messages to any channel
  - Quick moderation: kick, ban, timeout, warn users
  - Channel management: lock, unlock, slowmode, clear messages
  - Role management: add/remove roles
  - Member management: change nicknames
  - View warnings and server info
  - View announcements
- **Owner Panel Features** (50+ buttons):
  - All moderator features
  - Send announcements with @everyone ping
  - Full server statistics
  - Multi-page interface with advanced controls
  - Complete server management access

### Logging System
Automatically logs all server events to configured log channel:
- Member joins/leaves
- Nickname and role changes
- Message edits/deletions
- Channel creation/deletion
- Role creation/deletion
- Voice channel activity
- All moderation actions

## Project Architecture

### File Structure
```
├── main.py                 # Main bot file with event handlers
├── database.py             # Database utilities for accounts, warnings, logs
├── .env                    # Environment variables (not in repo)
├── .env.example            # Template for environment variables
├── utils/
│   ├── permissions.py      # Permission decorators for commands
│   └── embeds.py          # Embed utilities and gradient functions
└── cogs/
    ├── moderation.py       # All moderation commands
    ├── utility.py          # Utility and info commands
    ├── voice.py            # Voice channel management
    ├── panel.py            # Panel system with interactive embeds
    └── logging.py          # Event logging system
```

### Database Schema
- **user_accounts**: Stores panel account credentials (user_id, password_hash)
- **panel_configs**: Stores user panel configurations
- **warnings**: Tracks user warnings with moderator and reason
- **mod_logs**: Logs all moderation actions

## Configuration

### Required Environment Variables
Create a `.env` file with these values:

```env
DISCORD_TOKEN=your_discord_bot_token_here
MODERATIONS_ROLEID=your_moderator_role_id_here
OWNER_USERID=your_owner_user_id_here
LOG_CHANNEL_ID=your_log_channel_id_here
```

### How to Get These Values

1. **DISCORD_TOKEN**: 
   - Go to [Discord Developer Portal](https://discord.com/developers/applications)
   - Create a new application or select existing one
   - Go to "Bot" section
   - Click "Reset Token" to get your bot token

2. **MODERATIONS_ROLEID**:
   - Enable Developer Mode in Discord (Settings → Advanced → Developer Mode)
   - Right-click your moderator role → Copy ID

3. **OWNER_USERID**:
   - Right-click your username in Discord → Copy ID

4. **LOG_CHANNEL_ID**:
   - Right-click the channel where you want logs → Copy ID

### Bot Permissions
The bot needs these permissions:
- Manage Roles
- Manage Channels
- Kick Members
- Ban Members
- Moderate Members (for timeout)
- Manage Nicknames
- Manage Messages
- Read Message History
- Send Messages
- Embed Links
- Attach Files
- Move Members (voice)
- View Channels

### Invite Link
Use this URL format to invite the bot (replace CLIENT_ID with your bot's client ID):
```
https://discord.com/api/oauth2/authorize?client_id=CLIENT_ID&permissions=1099511627782&scope=bot
```

## User Preferences
- Family-friendly content filters applied to all responses
- Simple, clear command structure with vu! prefix
- Visual feedback with colored embeds for all actions
- Comprehensive help command for easy discovery

## Security Notes
- Passwords are hashed using SHA-256 (consider upgrading to bcrypt for production)
- Only the bot owner can create panel accounts
- Panel sessions timeout after 5 minutes of inactivity
- All moderation actions are logged with moderator attribution
- Permission checks on all sensitive commands

## Next Steps / Future Enhancements
- Add auto-moderation features (spam detection, banned words)
- Implement backup and restore for server configurations
- Add custom embed templates that users can save
- Create dashboard with server statistics
- Add rate limiting for login attempts
- Upgrade password hashing to bcrypt/argon2 with salt
