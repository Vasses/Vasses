import discord
from typing import List, Tuple
import colorsys

def hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
    """Convert hex color to RGB tuple"""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def rgb_to_hex(rgb: Tuple[int, int, int]) -> str:
    """Convert RGB tuple to hex color"""
    return '#{:02x}{:02x}{:02x}'.format(*rgb)

def interpolate_color(color1: Tuple[int, int, int], color2: Tuple[int, int, int], factor: float) -> Tuple[int, int, int]:
    """Interpolate between two RGB colors"""
    return tuple(int(color1[i] + (color2[i] - color1[i]) * factor) for i in range(3))

def create_gradient(start_hex: str, end_hex: str, steps: int = 10) -> List[int]:
    """Create a gradient between two colors, returns list of Discord color integers"""
    start_rgb = hex_to_rgb(start_hex)
    end_rgb = hex_to_rgb(end_hex)
    
    gradient = []
    for i in range(steps):
        factor = i / (steps - 1) if steps > 1 else 0
        rgb = interpolate_color(start_rgb, end_rgb, factor)
        # Convert to Discord color integer
        color_int = (rgb[0] << 16) + (rgb[1] << 8) + rgb[2]
        gradient.append(color_int)
    
    return gradient

def create_embed(title: str = None, description: str = None, color: int = 0x5865F2, **kwargs) -> discord.Embed:
    """Create a standard embed with common settings"""
    embed = discord.Embed(title=title, description=description, color=color)
    
    if 'footer' in kwargs:
        embed.set_footer(text=kwargs['footer'])
    if 'image' in kwargs:
        embed.set_image(url=kwargs['image'])
    if 'thumbnail' in kwargs:
        embed.set_thumbnail(url=kwargs['thumbnail'])
    if 'author' in kwargs:
        embed.set_author(name=kwargs['author'])
    
    return embed

def success_embed(message: str, title: str = "✅ Success") -> discord.Embed:
    """Create a success embed"""
    return discord.Embed(title=title, description=message, color=0x00FF00)

def error_embed(message: str, title: str = "❌ Error") -> discord.Embed:
    """Create an error embed"""
    return discord.Embed(title=title, description=message, color=0xFF0000)

def info_embed(message: str, title: str = "ℹ️ Information") -> discord.Embed:
    """Create an info embed"""
    return discord.Embed(title=title, description=message, color=0x5865F2)

def warning_embed(message: str, title: str = "⚠️ Warning") -> discord.Embed:
    """Create a warning embed"""
    return discord.Embed(title=title, description=message, color=0xFFAA00)
