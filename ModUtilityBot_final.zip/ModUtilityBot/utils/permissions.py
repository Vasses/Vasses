import discord
from discord.ext import commands
import os

def is_moderator():
    """Check if user has moderator role"""
    async def predicate(ctx):
        mod_role_id = int(os.getenv('MODERATIONS_ROLEID', 0))
        if mod_role_id == 0:
            await ctx.send("❌ Moderator role ID is not configured!")
            return False
        
        # Owner bypass
        owner_id = int(os.getenv('OWNER_USERID', 0))
        if ctx.author.id == owner_id:
            return True
        
        # Check for moderator role
        if isinstance(ctx.author, discord.Member):
            return any(role.id == mod_role_id for role in ctx.author.roles)
        return False
    
    return commands.check(predicate)

def is_owner():
    """Check if user is the bot owner"""
    async def predicate(ctx):
        owner_id = int(os.getenv('OWNER_USERID', 0))
        if ctx.author.id == owner_id:
            return True
        await ctx.send("❌ Only the bot owner can use this command!")
        return False
    
    return commands.check(predicate)
